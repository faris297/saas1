import React from 'react';

function Home() {
  return (
    <div>
      <h1>مرحبًا بك في أكاديمية كرة القدم</h1>
    </div>
  );
}

export default Home;